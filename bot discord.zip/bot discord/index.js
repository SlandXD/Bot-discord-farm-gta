// =============================
// 🤖 BOT DE FARM COMPLETO E DINÂMICO
// =============================

const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionsBitField,
} = require("discord.js");
const fs = require("fs");
const cron = require("node-cron");

// 🧩 CONFIGURAÇÕES DO BOT
const TOKEN = "MTQzNTQyNTE2MjI4MjY2Mzk4Ng.G4Pciq.1HUyhGkTEFt5UrkTStgKWUCuEIb_mXymmlo0fc";
const ID_CANAL_LOGS = "1416951282656350210";
const ID_CARGO_APROVADOR = "1416951281423224874";

// =============================
// 🔧 INICIALIZAÇÃO
// =============================
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
});

const arquivoFarm = "./farmData.json";
const arquivoMetas = "./metasConfig.json";

let dados = fs.existsSync(arquivoFarm) ? JSON.parse(fs.readFileSync(arquivoFarm)) : {};

let configMetas = {
  diaria: { ativa: true, valor: 500 },
  semanal: { ativa: true, valor: 2500 },
  mensal: { ativa: true, valor: 15000 },
};

if (fs.existsSync(arquivoMetas)) {
  try {
    configMetas = JSON.parse(fs.readFileSync(arquivoMetas, "utf8"));
  } catch {
    console.log("⚠️ Erro ao carregar metas, usando padrão.");
  }
}

function salvarMetas() {
  fs.writeFileSync(arquivoMetas, JSON.stringify(configMetas, null, 2));
}
function salvarFarms() {
  fs.writeFileSync(arquivoFarm, JSON.stringify(dados, null, 2));
}

// =============================
// 🕒 RESET AUTOMÁTICO
// =============================
client.once("ready", () => {
  console.log(`✅ Bot logado como ${client.user.tag}`);

  // Reset diário
  cron.schedule("0 0 * * *", () => {
    for (const canalId in dados)
      for (const userId in dados[canalId]) dados[canalId][userId].diario = 0;
    salvarFarms();
    console.log("🔁 Reset diário concluído");
  });

  // Reset semanal (segunda-feira 00h00)
  cron.schedule("0 0 * * 1", () => {
    for (const canalId in dados)
      for (const userId in dados[canalId]) dados[canalId][userId].semanal = 0;
    salvarFarms();
    console.log("📆 Reset semanal concluído");
  });

  // Reset mensal
  cron.schedule("0 0 1 * *", async () => {
    const canal = client.channels.cache.get(ID_CANAL_LOGS);
    if (canal) canal.send({ embeds: [gerarRankingEmbed()] });

    for (const canalId in dados)
      for (const userId in dados[canalId]) dados[canalId][userId].mensal = 0;

    salvarFarms();
    console.log("📅 Reset mensal concluído");
  });
});

// =============================
// 🧩 FUNÇÕES DE INTERFACE
// =============================
function gerarPainelEmbed() {
  return new EmbedBuilder()
    .setColor("#2ecc71")
    .setTitle("💰 Painel de Farm")
    .setDescription("Gerencie e acompanhe seu progresso de farm!")
    .addFields(
      { name: "📆 Meta Diária", value: configMetas.diaria.ativa ? `${configMetas.diaria.valor}` : "❌ Desativada", inline: true },
      { name: "🗓️ Meta Semanal", value: configMetas.semanal.ativa ? `${configMetas.semanal.valor}` : "❌ Desativada", inline: true },
      { name: "🏆 Meta Mensal", value: configMetas.mensal.ativa ? `${configMetas.mensal.valor}` : "❌ Desativada", inline: true },
    );
}

function gerarBotoesPainel() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("add_farm").setLabel("📤 Adicionar Farm").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("ver_farm").setLabel("📈 Ver Meu Farm").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ver_ranking").setLabel("🏅 Ver Ranking").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("config_metas").setLabel("⚙️ Configurar Metas").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("limpar_farm").setLabel("🧹 Limpar Farm").setStyle(ButtonStyle.Secondary),
  );
}

function gerarRankingEmbed() {
  const todos = [];
  for (const canalId in dados)
    for (const userId in dados[canalId])
      todos.push({ id: userId, total: dados[canalId][userId].mensal });

  const ranking = todos.sort((a, b) => b.total - a.total).slice(0, 10);
  const desc = ranking.length
    ? ranking.map((p, i) => `**${i + 1}.** <@${p.id}> — ${p.total}`).join("\n")
    : "Ninguém farmou ainda este mês.";

  return new EmbedBuilder().setColor("#9b59b6").setTitle("🏆 Ranking Mensal de Farm").setDescription(desc);
}

// =============================
// 📬 COMANDO !painel
// =============================
let painelAtual = null;

client.on("messageCreate", async (msg) => {
  if (msg.author.bot) return;
  if (msg.content !== "!painel") return;
  if (!msg.member.permissions.has(PermissionsBitField.Flags.Administrator))
    return msg.reply("⛔ Apenas administradores podem criar o painel.");

  const embed = gerarPainelEmbed();
  const botoes = gerarBotoesPainel();
  const mensagem = await msg.channel.send({ embeds: [embed], components: [botoes] });

  painelAtual = mensagem;
});

// =============================
// 🧠 INTERAÇÕES
// =============================
client.on("interactionCreate", async (i) => {
  if (i.isButton()) {
    const id = i.customId;

    // 📤 ADICIONAR FARM
    if (id === "add_farm") {
      const modal = new ModalBuilder()
        .setCustomId("modal_add_farm")
        .setTitle("📤 Registrar Farm");

      const qtdInput = new TextInputBuilder()
        .setCustomId("quantidade_farm")
        .setLabel("Quantidade de Farm")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder("Ex: 250")
        .setRequired(true);

      const imgInput = new TextInputBuilder()
        .setCustomId("imagem_farm")
        .setLabel("Link da Imagem (opcional)")
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

      modal.addComponents(
        new ActionRowBuilder().addComponents(qtdInput),
        new ActionRowBuilder().addComponents(imgInput),
      );

      return i.showModal(modal);
    }

    // 📈 VER MEU FARM (AGORA COM SEMANAL)
    if (id === "ver_farm") {
      const userId = i.user.id;
      const canalId = i.channel.id;
      if (!dados[canalId] || !dados[canalId][userId])
        return i.reply({ content: "😅 Você ainda não registrou nenhum farm!", ephemeral: true });

      const d = dados[canalId][userId];
      const embed = new EmbedBuilder()
        .setColor("#3498db")
        .setTitle(`📊 Progresso de ${i.user.username}`)
        .addFields(
          { name: "📆 Hoje", value: configMetas.diaria.ativa ? `${d.diario}/${configMetas.diaria.valor}` : "Desativada", inline: true },
          { name: "🗓️ Semana", value: configMetas.semanal.ativa ? `${d.semanal}/${configMetas.semanal.valor}` : "Desativada", inline: true },
          { name: "🏆 Mês", value: configMetas.mensal.ativa ? `${d.mensal}/${configMetas.mensal.valor}` : "Desativada", inline: true },
        );

      return i.reply({ embeds: [embed], ephemeral: true });
    }

    // 🏅 RANKING
    if (id === "ver_ranking") {
      return i.reply({ embeds: [gerarRankingEmbed()], ephemeral: true });
    }

    // ⚙️ CONFIGURAÇÕES DE METAS
    if (id === "config_metas") {
      if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return i.reply({ content: "⛔ Apenas administradores podem alterar metas.", ephemeral: true });

      const embed = new EmbedBuilder()
        .setColor("#f1c40f")
        .setTitle("⚙️ Configurações de Metas")
        .setDescription("Ative/desative ou altere o valor das metas.")
        .addFields(
          { name: "📆 Meta Diária", value: configMetas.diaria.ativa ? `✅ ${configMetas.diaria.valor}` : "❌ Desativada" },
          { name: "🗓️ Meta Semanal", value: configMetas.semanal.ativa ? `✅ ${configMetas.semanal.valor}` : "❌ Desativada" },
          { name: "🏆 Meta Mensal", value: configMetas.mensal.ativa ? `✅ ${configMetas.mensal.valor}` : "❌ Desativada" },
        );

      const botoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("toggle_diaria").setLabel("📆 Alternar Diária").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("toggle_semanal").setLabel("🗓️ Alternar Semanal").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("toggle_mensal").setLabel("🏆 Alternar Mensal").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("editar_valores").setLabel("✏️ Editar Valores").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("voltar_painel").setLabel("⬅️ Voltar ao Painel").setStyle(ButtonStyle.Success),
      );

      return i.reply({ embeds: [embed], components: [botoes], ephemeral: true });
    }

    // 🧹 LIMPAR FARM
    if (id === "limpar_farm") {
      if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return i.reply({ content: "⛔ Apenas administradores podem limpar farms.", ephemeral: true });

      const botoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("limpar_diario").setLabel("📆 Limpar Diário").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("limpar_semanal").setLabel("🗓️ Limpar Semanal").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("limpar_mensal").setLabel("🏆 Limpar Mensal").setStyle(ButtonStyle.Primary),
      );

      const embed = new EmbedBuilder()
        .setColor("#e67e22")
        .setTitle("🧹 Limpar Farm")
        .setDescription("Escolha o que deseja limpar (somente administradores).");

      return i.reply({ embeds: [embed], components: [botoes], ephemeral: true });
    }

    // 🔄 LIMPEZAS
    if (id.startsWith("limpar_")) {
      const tipo = id.split("_")[1];
      for (const canalId in dados)
        for (const userId in dados[canalId]) dados[canalId][userId][tipo] = 0;

      salvarFarms();
      return i.reply({ content: `🧹 Farm **${tipo}** limpo com sucesso!`, ephemeral: true });
    }

    // Alternar metas
    if (id.startsWith("toggle_")) {
      const tipo = id.split("_")[1];
      configMetas[tipo].ativa = !configMetas[tipo].ativa;
      salvarMetas();

      if (painelAtual)
        painelAtual.edit({ embeds: [gerarPainelEmbed()], components: [gerarBotoesPainel()] });

      return i.reply({
        content: `✅ Meta **${tipo}** agora está: ${configMetas[tipo].ativa ? "Ativa ✅" : "Desativada ❌"}`,
        ephemeral: true,
      });
    }

    // ✏️ Editar valores
    if (id === "editar_valores") {
      const modal = new ModalBuilder()
        .setCustomId("modal_editar_valores")
        .setTitle("✏️ Editar Valores das Metas");

      const diaria = new TextInputBuilder()
        .setCustomId("meta_diaria")
        .setLabel(`Meta Diária (atual: ${configMetas.diaria.valor})`)
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

      const semanal = new TextInputBuilder()
        .setCustomId("meta_semanal")
        .setLabel(`Meta Semanal (atual: ${configMetas.semanal.valor})`)
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

      const mensal = new TextInputBuilder()
        .setCustomId("meta_mensal")
        .setLabel(`Meta Mensal (atual: ${configMetas.mensal.valor})`)
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

      modal.addComponents(
        new ActionRowBuilder().addComponents(diaria),
        new ActionRowBuilder().addComponents(semanal),
        new ActionRowBuilder().addComponents(mensal)
      );

      return i.showModal(modal);
    }

    // Voltar ao painel
    if (id === "voltar_painel") {
      return i.update({ embeds: [gerarPainelEmbed()], components: [gerarBotoesPainel()] });
    }
  }

  // 🧾 SUBMIT FARM
  if (i.isModalSubmit() && i.customId === "modal_add_farm") {
    const quantidade = parseInt(i.fields.getTextInputValue("quantidade_farm"));
    const imagem = i.fields.getTextInputValue("imagem_farm");

    if (isNaN(quantidade) || quantidade <= 0)
      return i.reply({ content: "⚠️ Valor inválido!", ephemeral: true });

    const canalLogs = client.channels.cache.get(ID_CANAL_LOGS);
    if (!canalLogs)
      return i.reply({ content: "❌ Canal de logs não encontrado!", ephemeral: true });

    const embed = new EmbedBuilder()
      .setColor("#f39c12")
      .setTitle("🕒 Farm Aguardando Aprovação")
      .setDescription(`**Usuário:** ${i.user}\n**Quantidade:** ${quantidade}`)
      .setFooter({ text: "Aguardando aprovação de moderador" });

    if (imagem && /^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)$/i.test(imagem)) embed.setImage(imagem);

    const botoes = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`aprovar_${i.user.id}_${quantidade}_${imagem || "null"}`).setLabel("✅ Aprovar").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`rejeitar_${i.user.id}`).setLabel("❌ Rejeitar").setStyle(ButtonStyle.Danger),
    );

    await canalLogs.send({ embeds: [embed], components: [botoes] });
    return i.reply({ content: "📤 Seu farm foi enviado para validação!", ephemeral: true });
  }

  // ✏️ Editar valores
  if (i.isModalSubmit() && i.customId === "modal_editar_valores") {
    const diaria = i.fields.getTextInputValue("meta_diaria");
    const semanal = i.fields.getTextInputValue("meta_semanal");
    const mensal = i.fields.getTextInputValue("meta_mensal");

    if (diaria && !isNaN(parseInt(diaria))) configMetas.diaria.valor = parseInt(diaria);
    if (semanal && !isNaN(parseInt(semanal))) configMetas.semanal.valor = parseInt(semanal);
    if (mensal && !isNaN(parseInt(mensal))) configMetas.mensal.valor = parseInt(mensal);

    salvarMetas();

    if (painelAtual)
      painelAtual.edit({ embeds: [gerarPainelEmbed()], components: [gerarBotoesPainel()] });

    return i.reply({ content: "✅ Valores atualizados com sucesso!", ephemeral: true });
  }

  // ✅ Aprovar/Rejeitar FARM
  if (i.isButton() && (i.customId.startsWith("aprovar_") || i.customId.startsWith("rejeitar_"))) {
    const membro = i.member;
    if (!membro.roles.cache.has(ID_CARGO_APROVADOR))
      return i.reply({ content: "⛔ Você não tem permissão para aprovar farms.", ephemeral: true });

    const [acao, userId, quantidade, imagem] = i.customId.split("_");
    const user = await client.users.fetch(userId);
    const canalId = i.channel.id;

    if (acao === "aprovar") {
      const q = parseInt(quantidade);
      if (!dados[canalId]) dados[canalId] = {};
      if (!dados[canalId][userId])
        dados[canalId][userId] = { diario: 0, semanal: 0, mensal: 0, comprovantes: [] };

      const userData = dados[canalId][userId];
      userData.diario += q;
      userData.semanal += q;
      userData.mensal += q;
      if (imagem && imagem !== "null") userData.comprovantes.push(imagem);
      salvarFarms();

      await i.update({
        embeds: [
          new EmbedBuilder().setColor("#2ecc71").setTitle("✅ Farm Aprovado").setDescription(`Farm de ${user} aprovado por ${i.user}!`),
        ],
        components: [],
      });

      await user.send(`✅ Seu farm de **${q}** foi aprovado!`);
    } else {
      await i.update({
        embeds: [
          new EmbedBuilder().setColor("#e74c3c").setTitle("❌ Farm Rejeitado").setDescription(`O farm de ${user} foi rejeitado.`),
        ],
        components: [],
      });
      await user.send(`❌ Seu farm foi rejeitado.`);
    }
  }
});

// =============================
// 🚀 LOGIN
// =============================
client.login(TOKEN);
